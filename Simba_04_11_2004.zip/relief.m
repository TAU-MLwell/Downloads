function weights = relief(X_train, Y_train);

% weights = relief(X_train, Y_train,extra_param);
%
% implamentation of relief for multi class.
%
% input: X_train(i,j) is the value of feature j in training instance i
%        Y_train(i) is the label of training instance i
%
% output: weights(j) is the weight of the j's feature. higher is better.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Written by Amir Navot & Ran Gilad-Bachrach                   %%
%% Date: April 1, 2004                                                                       %%
%% Last update: April 1, 2004 by Amir Navot                            %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


N = size(X_train,1);
p = size(X_train,2);

[P_pos, P_neg, mindist_pos, mindist_neg, marginList] = simbaHelper(X_train, X_train.^2, Y_train,  ones(1,p), 1:N);

%delta_pos = (X_train - X_train(P_pos,:)).^2; % this line cause "out of
%MEMORY error, the two following lines replace it
permat = spconvert([[(1:N)'; N], [P_pos(:); N], [ones(size(P_pos(:))); 0]]); 
delta_pos = (X_train - permat * X_train).^2;

%delta_neg = (X_train - X_train(P_neg,:)).^2; %%same
permat = spconvert([[(1:N)'; N], [P_neg(:); N], [ones(size(P_neg(:))); 0]]); 
delta_neg = (X_train - permat * X_train).^2;



weights = sum(delta_neg-delta_pos,1);
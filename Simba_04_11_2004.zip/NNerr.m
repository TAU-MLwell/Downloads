function errate = NNerr(weights, X_test, Y_test, X_train, Y_train, feat_num);

% errate = NNerr(w, X_test, Y_test,X_train,Y_train, feat_num);
%
% This function calculate the error of 1-NN on X_test when using  the given
% weights in order to calculate the distances.
%
% input:  weights(j) is the weight of feature j. larger is better.
 %              X_train(i,j) is the value of feature j in training instance i.
%               Y_train(i) is the label of training instance i.
%               X_test(i,j) is the value of feature j in test instance i.
%               Y_test(i) is the label of test instance i.
%               feat_num is the values of number of features to check
%     
% output: errate(k) is the errorachieved when using t1-NN with the top
%                 feat_num(k) features only.
% 
% plot(feat_num, errate) plots the error vs the number of features used.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Written by Amir Navot & Ran Gilad-Bachrach                   %%
%% Date: April 1, 2004                                                                       %%
%% Last update: June 13, 2004 by RGB                            %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


w = weights(:)';

[sw Iw] = sort(w);
Iw = fliplr(Iw);
errate = zeros(size(feat_num));
errate_balanced = zeros(size(feat_num));
param.dummy = 0;
Np = sum(Y_test>0);
Nn = sum(Y_test<=0);


for fi = 1:length(feat_num),
    f = feat_num(fi);
    idx_feat = Iw(1:f);
    NN = findNearestNeighbor(X_train, X_test, idx_feat);
    Y_resu = Y_train(NN);
    errate(fi) = sum(Y_resu~=Y_test)/length(Y_test);
 %   fprintf('%06d %1.5f\n',full(feat_num(fi)),full( errate(fi)));
%    disp(full([feat_num(fi) errate(fi)]));
end;

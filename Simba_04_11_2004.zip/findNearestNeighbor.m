function NN = findNearestNeighbor(prototypes, instances, idx_feat);

% NN = findNearestNeighbor(prototypes, instances, idx_feat);
%
% NN(i) is the index of the nearest neighbor to instances(i,:) in prototypes. 
% i.e. prototypes(NN(i),:) is the nearest neighbor to instances(i,:) in prototypes.
%
% input: 
%        prototypes(i,j) = the value of the j's features in prototype i
%        instances(i,j) = the value of the j's features in instance i
%        idx_feat: only features in idx_feat are taken in considaration.
%        i.e., features which are not in idx_feat are ignored in the
%        distances calculations.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Written by Amir Navot & Ran Gilad-Bachrach                   %%
%% Date: April 1, 2004                                                                       %%
%% Last update: April 1, 2004 by Amir Navot                            %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


P = prototypes';
S = instances';
alphas = zeros(1,size(P,1));
alphas(idx_feat) = 1;
alphas = alphas(:)';
Pnum = size(P,2);
Snum = size(S,2);

P2 =P.^2;
Pnorm = alphas * P2; % sum(P.^2,1);
PNorm = Pnorm(ones(1, Snum), :);
Snorm = (alphas * (S.^2))'; % sum(S.^2,1)';
SNorm = Snorm(:, ones(1,Pnum));

% Alphas = diag(alphas);
if Snum > 1,
    Alphas = spdiags(alphas',0,length(alphas),length(alphas));
    SP = 2 * (S'*Alphas) * P;
else,
    SP = 2 * (S'.*alphas) * P;
end


dists = SNorm + PNorm - SP;
% 
% Pnum = size(P,2);
% Snum = size(S,2);
% Pnorm = sum(P.^2,1);
% PNorm = Pnorm(ones(1, Snum), :);
% Snorm = sum(S.^2,1)';
% SNorm = Snorm(:, ones(1,Pnum));
% 
% SP = 2*S'*P;
% dists = SNorm + PNorm - 2*S'*P;

[mindist, NN] = min(dists,[],2);







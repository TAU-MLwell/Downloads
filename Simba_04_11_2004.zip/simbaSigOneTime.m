function alphas = simbaSigOneTime(X_train,  Y_train, extra_param);

% alphas = simbaSig(X_train,  Y_train, extra_param);
%
% This function runs simba with sigmoid utility function one time (i.e. with one starting point).
%
% input: X_train(i,j) is the value of feature j in training instance i
%        Y_train(i) is the label of training instance i
%        extra_param is a struct that may contain the following parameters for the
%        algorithm: 
%                  max_iter: the number of pathes on all training data. (default is 1)
%                  blocksize: the algorithm recaculate the distances after updating the features weights
%                             usig "blocksize" samples. (default is 1)
%                  beta: controles the utuility function u(m) = 1/(1+exp(-beta*m)). (default is beta=1)
%                  verbose: 1 for verbose, 0 otherwise (default is 0)
%
% output: alphas(j) is the weight of the j's feature. higher is better.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Written by Amir Navot & Ran Gilad-Bachrach                   %%
%% Date: April 1, 2004                                           %%
%% Last update: August 2nd, 2004 by Ran Gilad-Bachrach           %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(extra_param, 'verbose'), verbose = extra_param.verbose; else, verbose = 0;  end
if isfield(extra_param, 'blocksize'), blocksize = extra_param.blocksize; else, blocksize = 1; if verbose, disp(['blocksize = ' num2str(blocksize)]); end;end
if isfield(extra_param, 'max_iter'), max_iter = extra_param.max_iter; else, max_iter = 1; if verbose,disp(['max_iter = ' num2str(max_iter)]); end; end
if isfield(extra_param, 'beta'), beta = extra_param.beta; else, beta = 1; if verbose,disp(['beta = ' num2str(beta)]); end; end

feat_num = size(X_train,2);
N = size(X_train,1);
if blocksize > N,
    error('blocksize > N');
end
alphas = ones(1,feat_num);

X_train_square = (X_train.^2);
marginList = zeros(1,N);
for iter = 1:max_iter,
    perm = randperm(N);
    for bi = 0:blocksize:(N-blocksize),
        if(verbose & ~mod(bi,10))
            disp(bi);
        end;
        xi = (bi+1):(bi+blocksize);
        xs = perm(xi);
        F = alphas.^2;
        [pplus , pminus, delta_plus, delta_minus, marginList(xs)] = simbaHelper(X_train, X_train_square, Y_train, F, xs);

        J = find(delta_plus~=0 & delta_minus~=0);
                if (length(J)~=length(delta_minus))
            warning('distance to nearhit or nearmiss is 0');
            if isempty(J),
                continue;
            end
        end
        xs = xs(J);
        pplus = pplus(J);
        pminus = pminus(J);
        delta_plus = delta_plus(J);
        delta_minus = delta_minus(J);
        delta_plus = delta_plus(:);
        delta_minus = delta_minus(:);
        vecs1 = (X_train(xs,:) - X_train(pplus,:)).^2;
        vecs2 = (X_train(xs,:) - X_train(pminus,:)).^2;
        vecs1 = vecs1 ./ delta_plus(:, ones(1,feat_num));
        vecs2 = vecs2 ./ delta_minus(:, ones(1,feat_num));

        ebx = exp(-beta*(delta_minus-delta_plus)/2);
        dl = beta * ebx ./ ((1+ebx).^2);
        Dl = dl(:, ones(1,feat_num));
        Dlw = (vecs2 - vecs1) .* Dl;
        dw = (1/blocksize)*(sum(Dlw,1));
        alphas = alphas .* (1 + dw);
    end
    if bi < (N-blocksize),
        xi = (bi+blocksize+1):N;
        xs = perm(xi);
        F = alphas.^2;
        [pplus , pminus, delta_plus, delta_minus, marginList] = simbaHelper(X_train_t, P2, Y_train, F, xs);
    
        delta_plus = delta_plus(:);
        delta_minus = delta_minus(:);
        vecs1 = (X_train(xs,:) - X_train(pplus,:)).^2;
        vecs2 = (X_train(xs,:) - X_train(pminus,:)).^2;
        vecs1 = vecs1 ./ delta_plus(:, ones(1,feat_num));
        vecs2 = vecs2 ./ delta_minus(:, ones(1,feat_num));
        
        ebx = exp(-beta*(delta_minus-delta_plus)/2);
        dl = beta * ebx ./ ((1+ebx).^2);
        Dl = dl(:, ones(1,feat_num));
        Dlw = (vecs2 - vecs1) .* Dl;
        dw = (1/length(xi))*(sum(Dlw,1));

         alphas = alphas .* (1 + dw);
    end;
end




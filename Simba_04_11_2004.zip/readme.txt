Margin Based Feature Selection 
==============================

Readme file for release November 4th 2004.

This directory contains a Matlab implementation of Simba and G-flip
algorithms. We have developed these algorithms during NIPS 2003
feature selection challenge. For proper description of the algorithms
see the references in
http://www.cs.huji.ac.il/labs/learning/code/feature_selection/ 
An implementation of Relief (Kira & Rendell 1992) (for multi class
classification) is also given here.  

All the above mentioned algorithms perform feature selection in the
supervised multi-class classification setting. Simba and Relief return
a weights vector that allows the user to choose the features with
highest weight.  G-flip returns an "optimal" set of features.  

The documentation in the code is minimal and is more "how to
use" rather than "what is done". 

How to use:
- Call simba, relief or gflip function in order to run the
  corresponding algorithms. 
- Use  findNearestNeighbor to classify new instances.
- use demo to plot a demonstration on the provided toy problem.
- The rest of the functions are internal and used by the above functions.

Help
- in matlab use the help system to get more information on how to use
  the functions. Type 'help <function name>' to get the appropriate
  help. 


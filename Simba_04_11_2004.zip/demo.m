function demo;

% demo;
%
% This function run the different features selection functions on a data
% set and plot the accuracy 1-NN achiev, as function of the number of
% features used by the different methods.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Written by Amir Navot & Ran Gilad-Bachrach                   %%
%% Date: April 1, 2004                                           %%
%% Last update: November 4, 2004 by Amir Navot                   %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('Load data ...')
% The demo data is a Xor toy problem (dim =10, y =sign(x(1)*x(2)*x(3))
load demo_data; % load the X_train, X_test, Y_tarain, Y_test. 

% RELIEF
disp('Run RELIEF');
weights_relief = relief(X_train, Y_train);

% SIMBA
disp('Run SIMBA with linear utility');
extra_param.max_iter = 1;
extra_start_poits=10;
weights_simba_lin = simba(X_train, Y_train,extra_param);
extra_param.utility = 'sigmoid';
disp('Run SIMBA with sigmoid utility');
extra_param.beta = 1;
weights_simba_sig = simba(X_train, Y_train,extra_param);

% GFLIP
disp('Run GFLIP with linear utility');
clear extara_param;
extra_param.max_iter = 5;
extra_param.start_points=10;
[idx_feat_gflip_lin, score] = gflip(X_train, Y_train, extra_param);

disp('Run GFLIP with sigmoid utility');
extra_param.utility = 'sigmoid';
[idx_feat_gflip_sig, score] = gflip(X_train, Y_train, extra_param);


disp('Run GFLIP with zero-one utility');
extra_param.utility = 'zero-one';
[idx_feat_gflip_zo, score] = gflip(X_train, Y_train, extra_param);

% Error calculations
disp('Calculate errate');
feat_num = 1:10;

errate_relief = NNerr(weights_relief, X_test, Y_test, X_train, Y_train, feat_num);
errate_simba_lin = NNerr(weights_simba_lin, X_test, Y_test, X_train, Y_train, feat_num);
errate_simba_sig = NNerr(weights_simba_sig, X_test, Y_test, X_train, Y_train, feat_num);

weights_gflip = zeros(size(weights_relief));
weights_gflip(idx_feat_gflip_lin) = 1;
errate_gflip_lin = NNerr(weights_gflip, X_test, Y_test, X_train, Y_train, length(idx_feat_gflip_lin));
weights_gflip = zeros(size(weights_relief));
weights_gflip(idx_feat_gflip_sig) = 1;
errate_gflip_sig = NNerr(weights_gflip, X_test, Y_test, X_train, Y_train, length(idx_feat_gflip_sig));
weights_gflip = zeros(size(weights_relief));
weights_gflip(idx_feat_gflip_zo) = 1;
errate_gflip_zo = NNerr(weights_gflip, X_test, Y_test, X_train, Y_train, length(idx_feat_gflip_zo));

% Plotting:
disp('plot');
figure;

line_width = 2;
font_size = 12;
font_weight = 'Bold';
line_width = 2;
text_font_size = 12;

% line_style1 = 'k--';
% line_style2 = 'k-.';
% line_style3 = 'k:';
% line_style4 = 'k-';

line_style1 = 'b';
line_style2 = 'r';
line_style3 = 'm';
line_style4 = 'k';


ph_relief = plot(feat_num, 100-100*errate_relief, line_style1,'LineWidth', line_width);
hold on;
ph_simba_lin = plot(feat_num, 100-100*errate_simba_lin, line_style2, 'LineWidth', line_width);
ph_simba_sig = plot(feat_num, 100-100*errate_simba_sig, line_style3, 'LineWidth', line_width);
ph_gflip_lin = plot(length(idx_feat_gflip_lin), 100-100*errate_gflip_lin, 'kd', 'MarkerSize', 8, 'LineWidth',2);
ph_gflip_sig = plot(length(idx_feat_gflip_sig), 100-100*errate_gflip_sig, 'go', 'MarkerSize', 12, 'LineWidth',2);
ph_gflip_zo = plot(length(idx_feat_gflip_zo), 100-100*errate_gflip_zo, 'ys', 'MarkerSize', 5, 'LineWidth',2);



lh = legend([ph_gflip_lin ph_gflip_sig ph_gflip_zo ph_simba_lin ph_simba_sig ph_relief],'G-flip (lin), 10 start points' , 'G-flip (sig), 10 start points' ,'G-flip (zo), 10 start points' , 'Simba (lin), 10 start points', 'Simba (sig), 10 start points', 'Relief');
set(lh, 'FontSize', font_size);
set(lh, 'FontWeight', font_weight);
xlabel('Number of Selected Features', 'FontWeight', font_weight, 'FontSize', text_font_size);
ylabel('Accuracy (%)', 'FontWeight', font_weight, 'FontSize', text_font_size);
title('Accuracy on Xor toy problem (dim =10, y = sign(x(1)*x(2)*x(3))', 'FontWeight', font_weight, 'FontSize', text_font_size);
set(gca, 'FontSize', font_size)
set(gca, 'FontWeight', font_weight)
axis([1 10 40 100]);